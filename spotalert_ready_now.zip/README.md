# SpotAlert — MVP (Static)
One-page MVP ready for Vercel static hosting.

## What’s inside
- `index.html` — main UI (camera, report form, Shira widget)
- `styles.css` — styling
- `app.js` — camera & report logic (all local)
- `shira.js` — small helper widget
- `assets/logo.svg` — logo
- `vercel.json` — static hosting config
