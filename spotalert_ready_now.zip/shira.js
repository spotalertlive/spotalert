
(() => {
  const toggle = document.getElementById("shiraToggle");
  const panel = document.getElementById("shiraPanel");
  const ask = document.getElementById("shiraAsk");
  const input = document.getElementById("shiraInput");
  const out = document.getElementById("shiraOut");

  toggle.addEventListener("click", () => panel.classList.toggle("hide"));
  ask.addEventListener("click", () => {
    const q = (input.value||'').toLowerCase();
    if(!q){ out.textContent = "Ask me about camera, reports, or alerts."; return; }
    let a = "I'm here to help!";
    if(q.includes("camera")) a = "Use Start Camera ▶ to begin, Capture Frame to take a snapshot, and Stop to end.";
    else if(q.includes("report")) a = "Fill Title/Severity/Notes and click Save Report — it downloads a JSON locally.";
    else if(q.includes("alert")) a = "This MVP uses local-only actions. Email/SMS/webhook are wired as future toggles.";
    else if(q.includes("contact")) a = "Email support@spotalert.live — the team will reply promptly.";
    out.textContent = a;
  });
})();
