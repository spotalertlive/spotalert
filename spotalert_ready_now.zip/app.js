
(() => {
  const $ = (s) => document.querySelector(s);
  const video = $("#video");
  const canvas = $("#canvas");
  const ctx = canvas.getContext("2d");
  const camStatus = $("#camStatus");
  const year = $("#year");
  year.textContent = new Date().getFullYear();

  let stream = null;
  async function start() {
    try{
      stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      video.srcObject = stream;
      camStatus.textContent = "Camera running.";
    }catch(e){
      camStatus.textContent = "Unable to start camera: " + e.message;
    }
  }
  function stop() {
    if(stream){
      stream.getTracks().forEach(t => t.stop());
      stream = null;
      camStatus.textContent = "Camera stopped.";
    }
  }
  function capture() {
    if(!video.videoWidth){ camStatus.textContent = "Start the camera first."; return; }
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    canvas.classList.remove("hide");
    camStatus.textContent = "Frame captured.";
  }
  function downloadSnapshot(){
    if(canvas.classList.contains("hide")){ camStatus.textContent = "Capture a frame first."; return; }
    const link = document.createElement("a");
    link.download = "spotalert_snapshot_"+Date.now()+".png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  }
  function saveReport(){
    const data = {
      title: document.getElementById("rTitle").value || "Untitled incident",
      severity: document.getElementById("rSeverity").value,
      notes: document.getElementById("rNotes").value,
      ts: new Date().toISOString(),
      hasSnapshot: !canvas.classList.contains("hide"),
    };
    const blob = new Blob([JSON.stringify(data,null,2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "spotalert_report_"+Date.now()+".json";
    a.click(); URL.revokeObjectURL(url);
    document.getElementById("saveStatus").textContent = "Report saved locally (JSON downloaded).";
  }

  document.getElementById("btnStart").addEventListener("click", start);
  document.getElementById("btnStop").addEventListener("click", stop);
  document.getElementById("btnCapture").addEventListener("click", capture);
  document.getElementById("btnDownload").addEventListener("click", downloadSnapshot);
  document.getElementById("btnSaveReport").addEventListener("click", saveReport);
})();
